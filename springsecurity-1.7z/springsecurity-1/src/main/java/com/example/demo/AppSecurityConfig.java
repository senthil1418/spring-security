package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class AppSecurityConfig extends WebSecurityConfigurerAdapter{
	/*
	 * @Bean
	 * 
	 * @Override protected UserDetailsService userDetailsService(){
	 * List<UserDetails> users=new ArrayList<>();
	 * users.add(User.withDefaultPasswordEncoder().username("abc").password("123").
	 * roles("USER").build()); return new InMemoryUserDetailsManager(users); }
	 */
	
	  @Autowired private UserDetailsService userDetailsService;
	  
	  @Bean public AuthenticationProvider authProvider(){ DaoAuthenticationProvider
	  provider=new DaoAuthenticationProvider();
	  provider.setUserDetailsService(userDetailsService); //
	//  provider.setPasswordEncoder(NoOpPasswordEncoder.getInstance()); provider.
	  provider.setPasswordEncoder(new BCryptPasswordEncoder()); return provider; }
	 
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
	      http
	           .csrf().disable()  //Cross-Site Request Forgery. It is an attack that forces an end user to execute unwanted actions on a web application in which they are currently authenticated.
	           .authorizeRequests().antMatchers("/login").permitAll()
	           .anyRequest().authenticated()
	           .and()
	           .formLogin()   //to add our own login page
	           .loginPage("/login").permitAll()
	           .and()  //we also specify what happens when logout
	           .logout().invalidateHttpSession(true) //spring invalidates the session
	           .clearAuthentication(true)  //clears all user once logout
	           .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))//what is request type (ie) when do u say person is logout /logout or /out like 
	           .logoutSuccessUrl("/logout-success").permitAll();//which url is called after logout
	}
}